﻿#ifndef _TB6612_H_
#define _TB6612_H_

#include "ti_msp_dl_config.h"
#include "board.h"
#include "stdint.h"

#define AIN1_OUT(X)  ( (X) ? (DL_GPIO_setPins(TB6612_AIN1_PORT,TB6612_AIN1_PIN)) : (DL_GPIO_clearPins(TB6612_AIN1_PORT,TB6612_AIN1_PIN)) )
#define AIN2_OUT(X)  ( (X) ? (DL_GPIO_setPins(TB6612_AIN2_PORT,TB6612_AIN2_PIN)) : (DL_GPIO_clearPins(TB6612_AIN2_PORT,TB6612_AIN2_PIN)) )

#define BIN1_OUT(X)  ( (X) ? (DL_GPIO_setPins(TB6612_BIN1_PORT,TB6612_BIN1_PIN)) : (DL_GPIO_clearPins(TB6612_BIN1_PORT,TB6612_BIN1_PIN)) )
#define BIN2_OUT(X)  ( (X) ? (DL_GPIO_setPins(TB6612_BIN2_PORT,TB6612_BIN2_PIN)) : (DL_GPIO_clearPins(TB6612_BIN2_PORT,TB6612_BIN2_PIN)) )

#define STBY_OUT(X)  ( (X) ? (DL_GPIO_setPins(TB6612_STBY_PORT,TB6612_STBY_PIN)) : (DL_GPIO_clearPins(TB6612_STBY_PORT,TB6612_STBY_PIN)) )

/*
 * TB6612 方向切换死区时间（单位：CPU 延时周期）
 * 12V大电流换向时，若AIN1/AIN2方向脚切换与PWM不同步，
 * 会出现H桥上下管瞬间直通（shoot-through），导致TB6612发烫甚至烧毁。
 * 流程：关PWM → 刹车(1,1) → 等待死区 → 写新方向 → 等待死区 → 恢复PWM
 * 32MHz主频下：1000个周期约31μs；远大于TB6612所需的死区时间(典型200ns)，留足余量
 */
#define TB6612_DEADTIME_CYCLES  (1200u)

/* PWM 单次变化率最大值（防止PID突变带来的电流冲击，每个控制周期最多变化这么多） */
/* 必须大于电机死区45，否则电机无法启动；设置为50既能启动又能限制冲击 */
#define TB6612_MAX_STEP_PER_CTRL  (50u)

/* 通道索引：用于内部状态跟踪 */
#define TB6612_CH_A   (0u)
#define TB6612_CH_B   (1u)

void TB6612_Motor_Stop(void);
void AO_Control(uint8_t dir, uint32_t speed);
void BO_Control(uint8_t dir, uint32_t speed);

#endif  /* _TB6612_H_ */