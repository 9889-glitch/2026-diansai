﻿#ifndef _PID_H_
#define _PID_H_

#include "stdint.h"

/* PID结构体定义（与参考工程一致） */
typedef struct {
    float Kp, Ki, Kd;           /* 三个静态系数 */
    float target;               /* 目标值（cm/s） */
    float actual;               /* 当前实际值（cm/s） */
    float error, last_error;    /* 当前误差、上次误差 */
    float integral;             /* 积分累加 */
    float output;               /* 输出值（PWM，范围 -999 ~ +999） */
} PID;

/* 电机A/B速度环PID实例（外部可见） */
extern PID speed_pid_A;
extern PID speed_pid_B;

/**
 * @brief PID计算函数（位置式PID）
 * @param pid     PID结构体指针
 * @param target  目标值（cm/s）
 * @param current 当前值（cm/s）
 * @return PID输出值（带符号）
 */
float pid_calc(PID *pid, float target, float current);

/**
 * @brief PID初始化函数
 * @param pid     PID结构体指针
 * @param p       Kp比例系数
 * @param i       Ki积分系数
 * @param d       Kd微分系数
 */
void pid_init(PID *pid, float p, float i, float d);

/**
 * @brief PID复位（清零误差和积分）
 * @param pid PID结构体指针
 */
void pid_reset(PID *pid);

/**
 * @brief 系统速度环PID初始化
 */
void System_PID_Init(void);

#endif
