#include "ti_msp_dl_config.h"
#include "LED.h"
#include "LCD.h"
#include "string.h"
#include "stdlib.h"
#include "math.h"
#include "TB6612.h"
#include "board.h"
#include "encoder.h"
#include "PID.h"
#include "vofa_protocol.h"

/* 目标速度：单位 cm/s */
float target_speed = 15.0f;

/* 当前实际速度（cm/s） */
float current_speed_A = 0.0f;
float current_speed_B = 0.0f;

/* PID输出PWM值（带符号） */
float pwm_out_A = 0.0f;
float pwm_out_B = 0.0f;

/* 上次实际输出的PWM值（用于速率限制） */
float last_pwm_A = 0.0f;
float last_pwm_B = 0.0f;

/* PWM单次最大变化量（每个控制周期40ms最多变化30） */
#define PWM_MAX_STEP 30.0f

/* 是否使能速度闭环（1=运行，0=停车） */
uint8_t pid_enable = 1;

/* 定时器中断计数器（用于诊断） */
volatile uint32_t timer_irq_count = 0;

/* 串口接收缓冲 */
#define UART_RX_BUF_SIZE 64
char uart_rx_buf[UART_RX_BUF_SIZE];
uint8_t uart_rx_len = 0;

/**
 * @brief 将PID输出转换为电机控制
 * @param which 0=电机A，1=电机B
 * @param pwm   PID输出值（带符号）
 */
static void motor_apply_pwm(uint8_t which, float pwm)
{
    uint8_t dir;
    uint32_t abs_pwm;
    float *last_pwm = (which == 0u) ? &last_pwm_A : &last_pwm_B;

    /* PWM速率限制：每个控制周期PWM变化不超过PWM_MAX_STEP */
    float delta = pwm - *last_pwm;
    if (delta > PWM_MAX_STEP) {
        pwm = *last_pwm + PWM_MAX_STEP;
    } else if (delta < -PWM_MAX_STEP) {
        pwm = *last_pwm - PWM_MAX_STEP;
    }

    *last_pwm = pwm;

    abs_pwm = (uint32_t)(fabsf(pwm) + 0.5f);

    /* 死区补偿：太小的占空比电机转不起来 */
    if (abs_pwm > 0u && abs_pwm < 45u) {
        abs_pwm = 45u;
    }

    /* 范围限制 */
    if (abs_pwm > 999u) abs_pwm = 999u;

    /* 方向判断：pwm>=0正转，pwm<0反转 */
    dir = (pwm >= 0.0f) ? 1u : 0u;

    if (which == 0u) {
        AO_Control(dir, abs_pwm);
    } else {
        BO_Control(dir, abs_pwm);
    }
}

/**
 * @brief 速度环控制一步（电机A和电机B独立PID）
 */
static void speed_pid_step(void)
{
    float vofa_data[5];
    float raw_speed_A, raw_speed_B;

    /* 获取原始编码器速度（cm/s） */
    raw_speed_A = encoder_get_speed_cm_s_A();
    raw_speed_B = encoder_get_speed_cm_s_B();

    if (pid_enable) {
        /* 使用原始速度（输入滤波已在encoder.c中处理） */
        current_speed_A = raw_speed_A;
        current_speed_B = raw_speed_B;

        /* 电机A独立PID计算 */
        pwm_out_A = pid_calc(&speed_pid_A, target_speed, current_speed_A);
        motor_apply_pwm(0, pwm_out_A);

        /* 电机B独立PID计算 */
        pwm_out_B = pid_calc(&speed_pid_B, target_speed, current_speed_B);
        motor_apply_pwm(1, pwm_out_B);
    } else {
        /* PID关闭时，显示原始编码器速度用于诊断 */
        current_speed_A = raw_speed_A;
        current_speed_B = raw_speed_B;
    }

    /* VOFA+ FireWater数据 */
    vofa_data[0] = target_speed;
    vofa_data[1] = current_speed_A;
    vofa_data[2] = current_speed_B;
    vofa_data[3] = pwm_out_A;
    vofa_data[4] = pwm_out_B;
    vofa_send_firewater(5, vofa_data);
}

/* 解析串口命令 */
void parse_uart_command(char *buf)
{
    float val;
    char cmd[16];

    if (sscanf(buf, "%15s", cmd) != 1) return;

    if (strcmp(cmd, "help") == 0 || strcmp(cmd, "?") == 0) {
        lc_printf("\r\n===== PID speed help =====\r\n");
        lc_printf("  st <val>    set target speed (cm/s)\r\n");
        lc_printf("  kp <val>    set Kp (both motors)\r\n");
        lc_printf("  ki <val>    set Ki (both motors)\r\n");
        lc_printf("  kd <val>    set Kd (both motors)\r\n");
        lc_printf("  kpa <val>   set Kp for motor A\r\n");
        lc_printf("  kpb <val>   set Kp for motor B\r\n");
        lc_printf("  kia <val>   set Ki for motor A\r\n");
        lc_printf("  kib <val>   set Ki for motor B\r\n");
        lc_printf("  kda <val>   set Kd for motor A\r\n");
        lc_printf("  kdb <val>   set Kd for motor B\r\n");
        lc_printf("  start       enable PID\r\n");
        lc_printf("  stop        disable PID\r\n");
        lc_printf("==========================\r\n");
    } else if (strcmp(cmd, "st") == 0) {
        if (sscanf(buf, "st %f", &val) == 1) {
            target_speed = val;
            lc_printf("target=%.1f cm/s\r\n", target_speed);
        }
    } else if (strcmp(cmd, "kp") == 0) {
        if (sscanf(buf, "kp %f", &val) == 1) {
            speed_pid_A.Kp = val;
            speed_pid_B.Kp = val;
            lc_printf("Kp=%.2f (both)\r\n", val);
        }
    } else if (strcmp(cmd, "ki") == 0) {
        if (sscanf(buf, "ki %f", &val) == 1) {
            speed_pid_A.Ki = val;
            speed_pid_B.Ki = val;
            lc_printf("Ki=%.2f (both)\r\n", val);
        }
    } else if (strcmp(cmd, "kd") == 0) {
        if (sscanf(buf, "kd %f", &val) == 1) {
            speed_pid_A.Kd = val;
            speed_pid_B.Kd = val;
            lc_printf("Kd=%.2f (both)\r\n", val);
        }
    } else if (strcmp(cmd, "kpa") == 0) {
        if (sscanf(buf, "kpa %f", &val) == 1) {
            speed_pid_A.Kp = val;
            lc_printf("KpA=%.2f\r\n", val);
        }
    } else if (strcmp(cmd, "kpb") == 0) {
        if (sscanf(buf, "kpb %f", &val) == 1) {
            speed_pid_B.Kp = val;
            lc_printf("KpB=%.2f\r\n", val);
        }
    } else if (strcmp(cmd, "kia") == 0) {
        if (sscanf(buf, "kia %f", &val) == 1) {
            speed_pid_A.Ki = val;
            lc_printf("KiA=%.2f\r\n", val);
        }
    } else if (strcmp(cmd, "kib") == 0) {
        if (sscanf(buf, "kib %f", &val) == 1) {
            speed_pid_B.Ki = val;
            lc_printf("KiB=%.2f\r\n", val);
        }
    } else if (strcmp(cmd, "kda") == 0) {
        if (sscanf(buf, "kda %f", &val) == 1) {
            speed_pid_A.Kd = val;
            lc_printf("KdA=%.2f\r\n", val);
        }
    } else if (strcmp(cmd, "kdb") == 0) {
        if (sscanf(buf, "kdb %f", &val) == 1) {
            speed_pid_B.Kd = val;
            lc_printf("KdB=%.2f\r\n", val);
        }
    } else if (strcmp(cmd, "start") == 0) {
        pid_enable = 1;
        pid_reset(&speed_pid_A);
        pid_reset(&speed_pid_B);
        last_pwm_A = 0.0f;  /* 重置上次PWM，确保速率限制生效 */
        last_pwm_B = 0.0f;
        lc_printf("PID start\r\n");
    } else if (strcmp(cmd, "stop") == 0) {
        pid_enable = 0;
        TB6612_Motor_Stop();
        last_pwm_A = 0.0f;
        last_pwm_B = 0.0f;
        lc_printf("PID stop\r\n");
    } else if (strcmp(cmd, "pwm") == 0) {
        /* 诊断命令：用固定PWM驱动电机，观察编码器读数 */
        int pwm_val;
        if (sscanf(buf, "pwm %d", &pwm_val) == 1) {
            pid_enable = 0;
            if (pwm_val >= 0) {
                AO_Control(1, (uint32_t)pwm_val);
                BO_Control(1, (uint32_t)pwm_val);
            } else {
                AO_Control(0, (uint32_t)(-pwm_val));
                BO_Control(0, (uint32_t)(-pwm_val));
            }
            lc_printf("manual PWM=%d\r\n", pwm_val);
        }
    }
}

void UART0_IRQHandler(void)
{
    if (DL_UART_Main_getPendingInterrupt(UART_0_INST) == DL_UART_MAIN_IIDX_RX) {
        char ch = DL_UART_Main_receiveData(UART_0_INST);
        if (ch == '\r' || ch == '\n') {
            if (uart_rx_len > 0) {
                uart_rx_buf[uart_rx_len] = '\0';
                parse_uart_command(uart_rx_buf);
                uart_rx_len = 0;
            }
        } else if (uart_rx_len < UART_RX_BUF_SIZE - 1) {
            uart_rx_buf[uart_rx_len++] = ch;
        }
        DL_UART_Main_clearInterruptStatus(UART_0_INST, DL_UART_MAIN_IIDX_RX);
    }
}

int main(void)
{
    uint16_t lcd_cnt = 0;
    char lcd_buf[32];

    SYSCFG_DL_init();

    NVIC_EnableIRQ(GPIOA_INT_IRQn);
    NVIC_EnableIRQ(GPIOB_INT_IRQn);
    NVIC_EnableIRQ(TIMER_TICK_INST_INT_IRQN);
    NVIC_EnableIRQ(UART_0_INST_INT_IRQN);

    encoder_init();
    System_PID_Init();

    lcd_init();
    LCD_Fill(0, 0, LCD_W, LCD_H, WHITE);

    DL_TimerG_startCounter(PWMA_INST);
    DL_TimerA_startCounter(PWMB_INST);
    DL_TimerA_startCounter(TIMER_TICK_INST);

    delay_ms(300);
    lc_printf("PID SPEED MODE target=%.1f cm/s\r\n", target_speed);
    lc_printf("KpA=%.1f KiA=%.1f KdA=%.1f\r\n", speed_pid_A.Kp, speed_pid_A.Ki, speed_pid_A.Kd);
    lc_printf("KpB=%.1f KiB=%.1f KdB=%.1f\r\n", speed_pid_B.Kp, speed_pid_B.Ki, speed_pid_B.Kd);
    lc_printf("VOFA+: FireWater, 5ch, 115200\r\n");

    /* 默认关闭PID，电机不转，先观察编码器原始数据 */
    pid_enable = 0;
    TB6612_Motor_Stop();
    pid_reset(&speed_pid_A);
    pid_reset(&speed_pid_B);

    while (1) {
        /* 每40ms有一次新速度采样 */
        if (encoder_speed_updated()) {
            speed_pid_step();
            timer_irq_count++;
        }

        /* LCD约200ms刷新一次 */
        if (++lcd_cnt >= 5) {
            lcd_cnt = 0;

            LCD_ShowString(0, 0, (const unsigned char *)"PID SPEED", RED, WHITE, 16, 0);

            sprintf(lcd_buf, "TGT:%.1f cm/s", target_speed);
            LCD_ShowString(0, 22, (const unsigned char *)lcd_buf, BLUE, WHITE, 12, 0);

            sprintf(lcd_buf, "A:%.1f PWM:%d", current_speed_A, (int)pwm_out_A);
            LCD_ShowString(0, 42, (const unsigned char *)lcd_buf, BLACK, WHITE, 12, 0);

            sprintf(lcd_buf, "B:%.1f PWM:%d", current_speed_B, (int)pwm_out_B);
            LCD_ShowString(0, 62, (const unsigned char *)lcd_buf, GREEN, WHITE, 12, 0);

            sprintf(lcd_buf, "KpA=%.1f KpB=%.1f", speed_pid_A.Kp, speed_pid_B.Kp);
            LCD_ShowString(0, 82, (const unsigned char *)lcd_buf, GRAY, WHITE, 12, 0);
        }

        delay_ms(1);
    }
}
