#include "ti_msp_dl_config.h"
#include "LED.h"
#include "LCD.h"
#include "string.h"
#include "TB6612.h"
#include "board.h"
#include "encoder.h"

// 电机速度，0-999范围
uint16_t motor_speed_A = 500;
uint16_t motor_speed_B = 500;
uint8_t motor_dir_A = 1;  // 1=正转, 0=反转
uint8_t motor_dir_B = 1;

// 串口接收缓冲区
#define UART_RX_BUF_SIZE 64
char uart_rx_buf[UART_RX_BUF_SIZE];
uint8_t uart_rx_len = 0;

// 解析串口命令
void parse_uart_command(char *buf)
{
    uint16_t speed;
    char cmd[16];
    
    if (sscanf(buf, "%s", cmd) == 1) {
        if (strcmp(cmd, "help") == 0 || strcmp(cmd, "?") == 0) {
            lc_printf("\r\n===== 电机控制帮助 =====\r\n");
            lc_printf("命令列表:\r\n");
            lc_printf("  sa <0-999>        设置电机A速度\r\n");
            lc_printf("  sb <0-999>        设置电机B速度\r\n");
            lc_printf("  da <0/1>          设置A方向 (0=反转, 1=正转)\r\n");
            lc_printf("  db <0/1>          设置B方向 (0=反转, 1=正转)\r\n");
            lc_printf("  stop              停止所有电机\r\n");
            lc_printf("  start             启动所有电机\r\n");
            lc_printf("================================\r\n");
        }
        else if (strcmp(cmd, "sa") == 0) {
            if (sscanf(buf, "sa %hu", &speed) == 1) {
                motor_speed_A = (speed > 999) ? 999 : speed;
                AO_Control(motor_dir_A, motor_speed_A);
                lc_printf("电机A速度: %d\r\n", motor_speed_A);
            }
        }
        else if (strcmp(cmd, "sb") == 0) {
            if (sscanf(buf, "sb %hu", &speed) == 1) {
                motor_speed_B = (speed > 999) ? 999 : speed;
                BO_Control(motor_dir_B, motor_speed_B);
                lc_printf("电机B速度: %d\r\n", motor_speed_B);
            }
        }
        else if (strcmp(cmd, "da") == 0) {
            if (sscanf(buf, "da %hhu", &motor_dir_A) == 1) {
                motor_dir_A = (motor_dir_A > 1) ? 1 : motor_dir_A;
                AO_Control(motor_dir_A, motor_speed_A);
                lc_printf("电机A方向: %d\r\n", motor_dir_A);
            }
        }
        else if (strcmp(cmd, "db") == 0) {
            if (sscanf(buf, "db %hhu", &motor_dir_B) == 1) {
                motor_dir_B = (motor_dir_B > 1) ? 1 : motor_dir_B;
                BO_Control(motor_dir_B, motor_speed_B);
                lc_printf("电机B方向: %d\r\n", motor_dir_B);
            }
        }
        else if (strcmp(cmd, "stop") == 0) {
            TB6612_Motor_Stop();
            lc_printf("电机已停止\r\n");
        }
        else if (strcmp(cmd, "start") == 0) {
            AO_Control(motor_dir_A, motor_speed_A);
            BO_Control(motor_dir_B, motor_speed_B);
            lc_printf("电机已启动\r\n");
        }
        else {
            lc_printf("未知命令: %s\r\n", cmd);
        }
    }
}

// UART中断处理函数
void UART0_IRQHandler(void)
{
    if (DL_UART_Main_getPendingInterrupt(UART_0_INST) == DL_UART_MAIN_IIDX_RX) {
        char ch = DL_UART_Main_receiveData(UART_0_INST);
        if (ch == '\r' || ch == '\n') {
            if (uart_rx_len > 0) {
                uart_rx_buf[uart_rx_len] = '\0';
                parse_uart_command(uart_rx_buf);
                uart_rx_len = 0;
            }
        } else if (uart_rx_len < UART_RX_BUF_SIZE - 1) {
            uart_rx_buf[uart_rx_len++] = ch;
        }
        DL_UART_Main_clearInterruptStatus(UART_0_INST, DL_UART_MAIN_IIDX_RX);
    }
}

int main(void)
{
    SYSCFG_DL_init();
    
    // 使能中断
    NVIC_EnableIRQ(GPIOA_INT_IRQn);
    NVIC_EnableIRQ(GPIOB_INT_IRQn);
    NVIC_EnableIRQ(TIMER_TICK_INST_INT_IRQN);
    NVIC_EnableIRQ(UART_0_INST_INT_IRQN);
    
    // 初始化编码器
    encoder_init();
    
    // 初始化LCD
    lcd_init();
    LCD_Fill(0, 0, LCD_W, LCD_H, WHITE);
    
    // 启动PWM定时器
    DL_TimerG_startCounter(PWMA_INST);
    DL_TimerA_startCounter(PWMB_INST);
    
    // 启动速度计算定时器
    DL_TimerA_startCounter(TIMER_TICK_INST);
    
    // 启动电机
    AO_Control(motor_dir_A, motor_speed_A);
    BO_Control(motor_dir_B, motor_speed_B);
    
    // 发送欢迎信息
    delay_ms(100);
    lc_printf("\r\n===== 电机控制 =====\r\n");
    lc_printf("A: 速度=%d 方向=%d | B: 速度=%d 方向=%d\r\n", 
              motor_speed_A, motor_dir_A, motor_speed_B, motor_dir_B);
    lc_printf("输入 'help' 获取命令帮助\r\n");
    
    while (1) 
    {
        // 获取编码器数据
        int32_t countA = encoder_get_countA();
        int32_t countB = encoder_get_countB();
        int32_t speedA = encoder_get_speedA();
        int32_t speedB = encoder_get_speedB();
        
        // 清屏
        LCD_Fill(0, 0, LCD_W, LCD_H, WHITE);
        
        // 显示标题，16号字体
        LCD_ShowString(0, 0, (const unsigned char*)"MOTOR", RED, WHITE, 16, 0);
        
        // 显示电机A数据，12号字体
        LCD_ShowString(0, 20, (const unsigned char*)"A:", BLUE, WHITE, 12, 0);
        LCD_ShowString(16, 20, (const unsigned char*)"spd=", BLUE, WHITE, 12, 0);
        LCD_ShowIntNum(48, 20, motor_speed_A, 4, BLUE, WHITE, 12);
        
        LCD_ShowString(0, 35, (const unsigned char*)"   cnt=", BLUE, WHITE, 12, 0);
        LCD_ShowIntNum(48, 35, countA, 6, BLUE, WHITE, 12);
        
        LCD_ShowString(0, 50, (const unsigned char*)"   spd=", BLUE, WHITE, 12, 0);
        LCD_ShowIntNum(48, 50, speedA, 5, BLUE, WHITE, 12);
        
        // 显示电机B数据，12号字体
        LCD_ShowString(0, 70, (const unsigned char*)"B:", GREEN, WHITE, 12, 0);
        LCD_ShowString(16, 70, (const unsigned char*)"spd=", GREEN, WHITE, 12, 0);
        LCD_ShowIntNum(48, 70, motor_speed_B, 4, GREEN, WHITE, 12);
        
        LCD_ShowString(0, 85, (const unsigned char*)"   cnt=", GREEN, WHITE, 12, 0);
        LCD_ShowIntNum(48, 85, countB, 6, GREEN, WHITE, 12);
        
        LCD_ShowString(0, 100, (const unsigned char*)"   spd=", GREEN, WHITE, 12, 0);
        LCD_ShowIntNum(48, 100, speedB, 5, GREEN, WHITE, 12);
        
        // 串口输出数据
        lc_printf("A: cnt=%6d spd=%4d | B: cnt=%6d spd=%4d\r\n", countA, speedA, countB, speedB);
        
        delay_ms(100);
    }
}
