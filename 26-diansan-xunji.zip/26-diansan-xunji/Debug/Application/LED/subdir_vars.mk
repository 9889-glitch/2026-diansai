################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Application/LED/LED.c 

C_DEPS += \
./Application/LED/LED.d 

OBJS += \
./Application/LED/LED.o 

OBJS__QUOTED += \
"Application\LED\LED.o" 

C_DEPS__QUOTED += \
"Application\LED\LED.d" 

C_SRCS__QUOTED += \
"../Application/LED/LED.c" 


