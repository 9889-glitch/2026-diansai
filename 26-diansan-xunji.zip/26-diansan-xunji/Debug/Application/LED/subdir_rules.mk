################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
Application/LED/%.o: ../Application/LED/%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Arm Compiler - building file: "$<"'
	"D:/ti/ccs2050/ccs/tools/compiler/ti-cgt-armllvm_4.0.4.LTS/bin/tiarmclang.exe" -c @"device.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -O2 -I"D:/TI project/workspace_ccstheia/26-diansan-xunji/Application/KEY" -I"D:/TI project/workspace_ccstheia/26-diansan-xunji/Application/PID" -I"D:/TI project/workspace_ccstheia/26-diansan-xunji/Application/MONTER" -I"D:/TI project/workspace_ccstheia/26-diansan-xunji/Application/LCD" -I"D:/TI project/workspace_ccstheia/26-diansan-xunji/Application/LED" -I"D:/TI project/workspace_ccstheia/26-diansan-xunji/Application" -I"D:/TI project/workspace_ccstheia/26-diansan-xunji" -I"D:/TI project/workspace_ccstheia/26-diansan-xunji/Debug" -I"D:/ti/ccs2050/mspm0_sdk_2_11_00_07/source/third_party/CMSIS/Core/Include" -I"D:/ti/ccs2050/mspm0_sdk_2_11_00_07/source" -g -Wall -MMD -MP -MF"Application/LED/$(basename $(<F)).d_raw" -MT"$(@)"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '


