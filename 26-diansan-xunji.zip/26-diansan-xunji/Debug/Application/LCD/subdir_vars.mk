################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Application/LCD/LCD.c 

C_DEPS += \
./Application/LCD/LCD.d 

OBJS += \
./Application/LCD/LCD.o 

OBJS__QUOTED += \
"Application\LCD\LCD.o" 

C_DEPS__QUOTED += \
"Application\LCD\LCD.d" 

C_SRCS__QUOTED += \
"../Application/LCD/LCD.c" 


