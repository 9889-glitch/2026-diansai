################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Application/UART/uart_debug.c 

C_DEPS += \
./Application/UART/uart_debug.d 

OBJS += \
./Application/UART/uart_debug.o 

OBJS__QUOTED += \
"Application\UART\uart_debug.o" 

C_DEPS__QUOTED += \
"Application\UART\uart_debug.d" 

C_SRCS__QUOTED += \
"../Application/UART/uart_debug.c" 


