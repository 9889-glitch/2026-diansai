################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Application/KEY/KEY.c \
../Application/KEY/hw_key.c \
../Application/KEY/mid_button.c 

C_DEPS += \
./Application/KEY/KEY.d \
./Application/KEY/hw_key.d \
./Application/KEY/mid_button.d 

OBJS += \
./Application/KEY/KEY.o \
./Application/KEY/hw_key.o \
./Application/KEY/mid_button.o 

OBJS__QUOTED += \
"Application\KEY\KEY.o" \
"Application\KEY\hw_key.o" \
"Application\KEY\mid_button.o" 

C_DEPS__QUOTED += \
"Application\KEY\KEY.d" \
"Application\KEY\hw_key.d" \
"Application\KEY\mid_button.d" 

C_SRCS__QUOTED += \
"../Application/KEY/KEY.c" \
"../Application/KEY/hw_key.c" \
"../Application/KEY/mid_button.c" 


