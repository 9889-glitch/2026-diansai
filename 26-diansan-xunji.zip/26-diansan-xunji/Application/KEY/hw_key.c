﻿#include "hw_key.h"

KEY_STATUS key_scan(void)
{
    KEY_STATUS states;
    // 读取每个按键的状态
    states.up = DL_GPIO_readPins(KEY_PIN_26_PORT, KEY_PIN_26_PIN) ? 1 : 0;
    states.left = DL_GPIO_readPins(KEY_PIN_29_PORT, KEY_PIN_29_PIN) ? 1 : 0;
    states.right = DL_GPIO_readPins(KEY_PIN_23_PORT, KEY_PIN_23_PIN) ? 1 : 0;
    states.down = DL_GPIO_readPins(KEY_PIN_25_PORT, KEY_PIN_25_PIN) ? 1 : 0;

    return states;
}

