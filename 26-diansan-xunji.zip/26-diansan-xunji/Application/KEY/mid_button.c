#include "mid_button.h"
#include "KEY.h"
#include "hw_key.h"

// 用户按键枚举定义
// 顺序必须与USER_BUTTON_MAX一致
typedef enum
{
    BUTTON_UP = 0,
    BUTTON_LEFT,
    BUTTON_RIGHT,
    BUTTON_DOWN,
    USER_BUTTON_MAX
} user_button_t;

static flex_button_t user_button[USER_BUTTON_MAX];

static flex_button_t *btn_head = NULL;

static uint16_t trg = 0;
static uint16_t cont = 0;
static uint16_t keydata = 0xFFFF;
static uint16_t key_rst_data = 0xFFFF;
static uint8_t button_cnt = 0;

#define EVENT_CB_EXECUTOR(button) if(button->cb) button->cb((flex_button_t*)button)
#define MAX_BUTTON_CNT 16


// 按键读取函数
static uint8_t button_up_read(void)     { return key_scan().up;     }
static uint8_t button_left_read(void)   { return key_scan().left;   }
static uint8_t button_right_read(void)  { return key_scan().right;  }
static uint8_t button_down_read(void)   { return key_scan().down;   }

// 用户按键初始化
// 注册所有用户按键及其回调函数
void user_button_init(void)
{
    int i;

    /* 清空按键数组 */
    memset(&user_button[0], 0x0, sizeof(user_button));

    user_button[BUTTON_UP].usr_button_read = button_up_read;//上键读取函数
    user_button[BUTTON_UP].cb = (flex_button_response_callback)btn_up_cb;//上键回调函数

    user_button[BUTTON_LEFT].usr_button_read = button_left_read;//左键读取函数
    user_button[BUTTON_LEFT].cb = (flex_button_response_callback)btn_left_cb;//左键回调函数

    user_button[BUTTON_RIGHT].usr_button_read = button_right_read;//右键读取函数
    user_button[BUTTON_RIGHT].cb = (flex_button_response_callback)btn_right_cb;//右键回调函数

    user_button[BUTTON_DOWN].usr_button_read = button_down_read;//下键读取函数
    user_button[BUTTON_DOWN].cb = (flex_button_response_callback)btn_down_cb;//下键回调函数

    /* 按键参数初始化 */

    for (i = 0; i < USER_BUTTON_MAX; i ++)
    {
        user_button[i].pressed_logic_level = 0; //按键按下时的逻辑电平
        user_button[i].click_start_tick = 7;//10;
        user_button[i].short_press_start_tick = 12;//20;//短按开始 tick
        user_button[i].long_press_start_tick = 27;//40;//长按开始 tick
        user_button[i].long_hold_start_tick = 32;//45;//长按保持开始tick

        flex_button_register(&user_button[i]);
    }
}

/**
 * @brief 注册一个用户按键
 *
 * @param button: 按键结构体指针
 * @return 注册成功返回按键数量，失败返回-1
*/
int8_t flex_button_register(flex_button_t *button)
{
    flex_button_t *curr = btn_head;

    if (!button || (button_cnt > MAX_BUTTON_CNT))
    {
        return -1;
    }

    while (curr)
    {
        if(curr == button)
        {
            return -1;  //already exist.
        }
        curr = curr->next;
    }

    button->next = btn_head;
    button->status = 0;
    button->event = FLEX_BTN_PRESS_NONE;
    button->scan_cnt = 0;
    button->click_cnt = 0;
    btn_head = button;
    key_rst_data = key_rst_data << 1;
    button_cnt ++;
    return button_cnt;
}

/**
 * @brief 读取所有按键状态并更新按键数据
 *
 * @param void
 * @return none
*/
static void flex_button_read(void)
{
    flex_button_t* target;
    uint16_t read_data = 0;
    keydata = key_rst_data;
    int8_t i = 0;

    for(target = btn_head, i = 0;
        (target != NULL) && (target->usr_button_read != NULL);
        target = target->next, i ++)
    {
        keydata = keydata |
                  (target->pressed_logic_level == 1 ?
                  ((!(target->usr_button_read)()) << i) :
                  ((target->usr_button_read)() << i));
    }

    read_data = keydata^0xFFFF;
    trg = read_data & (read_data ^ cont);
    cont = read_data;
}

/**
 * @brief 处理所有按键状态机并触发事件回调
 *        必须在 'flex_button_read' 之后调用
 *
 * @param void
 * @return none
*/
static void flex_button_process(void)
{
    int8_t i = 0;
    flex_button_t* target;

    for (target = btn_head, i = 0; target != NULL; target = target->next, i ++)
    {
        if (target->status > 0)
        {
            target->scan_cnt ++;
        }

        switch (target->status)
        {
            case 0: /* is default */
                if (trg & (1 << i)) /* is pressed */
                {
                    target->scan_cnt = 0;
                    target->click_cnt = 0;
                    target->status = 1;
                    target->event = FLEX_BTN_PRESS_DOWN;
                    EVENT_CB_EXECUTOR(target);
                }
                else
                {
                    target->event = FLEX_BTN_PRESS_NONE;
                }
                break;

            case 1: /* is pressed */
                if (!(cont & (1 << i))) /* is up */
                {
                    target->status = 2;
                }
                else if ((target->scan_cnt >= target->short_press_start_tick) &&
                        (target->scan_cnt < target->long_press_start_tick))
                {
                    target->status = 4;
                    target->event = FLEX_BTN_PRESS_SHORT_START;
                    EVENT_CB_EXECUTOR(target);
                }
                break;

            case 2: /* is up */
                if ((target->scan_cnt < target->click_start_tick))
                {
                    target->click_cnt++; // 1

                    if (target->click_cnt == 1)
                    {
                        target->status = 3;  /* double click check */
                    }
                    else
                    {
                        target->click_cnt = 0;
                        target->status = 0;
                        target->event = FLEX_BTN_PRESS_DOUBLE_CLICK;
                        EVENT_CB_EXECUTOR(target);
                    }
                }
                else if ((target->scan_cnt >= target->click_start_tick) &&
                    (target->scan_cnt < target->short_press_start_tick))
                {
                    target->click_cnt = 0;
                    target->status = 0;
                    target->event = FLEX_BTN_PRESS_CLICK;
                    EVENT_CB_EXECUTOR(target);
                }
                else if ((target->scan_cnt >= target->short_press_start_tick) &&
                    (target->scan_cnt < target->long_press_start_tick))
                {
                    target->click_cnt = 0;
                    target->status = 0;
                    target->event = FLEX_BTN_PRESS_SHORT_UP;
                    EVENT_CB_EXECUTOR(target);
                }
                else if ((target->scan_cnt >= target->long_press_start_tick) &&
                    (target->scan_cnt < target->long_hold_start_tick))
                {
                    target->click_cnt = 0;
                    target->status = 0;
                    target->event = FLEX_BTN_PRESS_LONG_UP;
                    EVENT_CB_EXECUTOR(target);
                }
                else if (target->scan_cnt >= target->long_hold_start_tick)
                {
                    /* long press hold up, not deal */
                    target->click_cnt = 0;
                    target->status = 0;
                    target->event = FLEX_BTN_PRESS_LONG_HOLD_UP;
                    EVENT_CB_EXECUTOR(target);
                }
                break;

            case 3: /* double click check */
                if (trg & (1 << i))
                {
                    target->click_cnt++;
                    target->status = 2;
                    target->scan_cnt --;
                }
                else if (target->scan_cnt >= target->click_start_tick)
                {
                    target->status = 2;
                }
                break;

            case 4: /* is short pressed */
                if (!(cont & (1 << i))) /* is up */
                {
                    target->status = 2;
                }
                else if ((target->scan_cnt >= target->long_press_start_tick) &&
                        (target->scan_cnt < target->long_hold_start_tick))
                {
                    target->status = 5;
                    target->event = FLEX_BTN_PRESS_LONG_START;
                    EVENT_CB_EXECUTOR(target);
                }
                break;

            case 5: /* is long pressed */
                if (!(cont & (1 << i))) /* is up */
                {
                    target->status = 2;
                }
                else if (target->scan_cnt >= target->long_hold_start_tick)
                {
                    target->status = 6;
                    target->event = FLEX_BTN_PRESS_LONG_HOLD;
                    EVENT_CB_EXECUTOR(target);
                }
                break;

            case 6: /* is long pressed */
                if (!(cont & (1 << i))) /* is up */
                {
                    target->status = 2;
                }
                break;
        }
    }
}

/**
 * flex_button_event_read
 *
 * @brief 获取按键当前事件
 *
 * @param button: 按键结构体指针
 * @return 当前事件类型
*/
flex_button_event_t flex_button_event_read(flex_button_t* button)
{
    return (flex_button_event_t)(button->event);
}

/**
 * flex_button_scan
 *
 * @brief 按键扫描函数
 *        必须周期性调用以检测按键状态变化
 *        推荐扫描周期5 - 20ms
 *
 * @param void
 * @return none
*/
void flex_button_scan(void)
{
    flex_button_read();
    flex_button_process();
}
