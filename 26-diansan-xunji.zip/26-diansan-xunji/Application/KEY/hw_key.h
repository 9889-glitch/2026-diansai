#ifndef _HW_KEY_H_
#define _HW_KEY_H_

#include "ti_msp_dl_config.h"

typedef struct {
    unsigned int up : 1;    // 上键状态
    unsigned int left : 1;  // 左键状态
    unsigned int right : 1; // 右键状态
    unsigned int down : 1;  // 下键状态
} KEY_STATUS;

KEY_STATUS key_scan(void);

#endif
