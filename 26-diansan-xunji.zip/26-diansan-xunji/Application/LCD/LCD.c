﻿#include "LCD.h"
#include "lcdfont.h"

#define 	delay_ms(X) 	delay_cycles( ( (CPUCLK_FREQ/1000) * (X) ) )

void spi_write_bus(unsigned char dat)
{
    //????????
    DL_SPI_transmitData8(SPI_LCD_INST, dat);
    //???SPI???????
    while(DL_SPI_isBusy(SPI_LCD_INST));
}

void LCD_Writ_Bus(unsigned char dat)
{
	LCD_CS_Clr();
	spi_write_bus(dat);
  LCD_CS_Set();
}
void LCD_WR_DATA8(unsigned char dat)
{
	LCD_Writ_Bus(dat);
}
void LCD_WR_DATA(unsigned int dat)
{
	LCD_Writ_Bus(dat>>8);
	LCD_Writ_Bus(dat);
}
void LCD_WR_REG(unsigned char dat)
{
	LCD_DC_Clr();//д????
	LCD_Writ_Bus(dat);
	LCD_DC_Set();//д????
}
void LCD_Address_Set(unsigned int x1,unsigned int y1,unsigned int x2,unsigned int y2)
{
	LCD_WR_REG(0x2a);//?е??????
	LCD_WR_DATA(x1 + 2);
	LCD_WR_DATA(x2 + 2);
	LCD_WR_REG(0x2b);//?е??????
	LCD_WR_DATA(y1 + 1);
	LCD_WR_DATA(y2 + 1);
	LCD_WR_REG(0x2c);//??????д
}
void lcd_init(void)
{
	/* GPIO??????λ??????г???? */

	LCD_RES_Clr();//??λ
	delay_ms(100);
	LCD_RES_Set();
	delay_ms(100);

	LCD_BLK_Set();//??????
	delay_ms(100);

	LCD_WR_REG(0x11);//Sleep exit 
	delay_ms(120);

	//ST7735S Frame Rate
	LCD_WR_REG(0xB1); 
	LCD_WR_DATA8(0x01); 
	LCD_WR_DATA8(0x2C); 
	LCD_WR_DATA8(0x2D); 

	LCD_WR_REG(0xB2); 
	LCD_WR_DATA8(0x01); 
	LCD_WR_DATA8(0x2C); 
	LCD_WR_DATA8(0x2D); 

	LCD_WR_REG(0xB3); 
	LCD_WR_DATA8(0x01); 
	LCD_WR_DATA8(0x2C); 
	LCD_WR_DATA8(0x2D); 
	LCD_WR_DATA8(0x01); 
	LCD_WR_DATA8(0x2C); 
	LCD_WR_DATA8(0x2D); 

	LCD_WR_REG(0xB4); //Column inversion 
	LCD_WR_DATA8(0x07); 

	//ST7735S Power Sequence
	LCD_WR_REG(0xC0); 
	LCD_WR_DATA8(0xA2); 
	LCD_WR_DATA8(0x02); 
	LCD_WR_DATA8(0x84); 

	LCD_WR_REG(0xC1); 
	LCD_WR_DATA8(0xC5); 

	LCD_WR_REG(0xC2); 
	LCD_WR_DATA8(0x0A); 
	LCD_WR_DATA8(0x00); 

	LCD_WR_REG(0xC3); 
	LCD_WR_DATA8(0x8A); 
	LCD_WR_DATA8(0x2A); 

	LCD_WR_REG(0xC4); 
	LCD_WR_DATA8(0x8A); 
	LCD_WR_DATA8(0xEE); 

	LCD_WR_REG(0xC5); //VCOM 
	LCD_WR_DATA8(0x0E); 

	LCD_WR_REG(0x36); //MX, MY, RGB mode 
	LCD_WR_DATA8(0xC0); 

	//ST7735S Gamma Sequence
	LCD_WR_REG(0xE0); 
	LCD_WR_DATA8(0x0F); 
	LCD_WR_DATA8(0x1A); 
	LCD_WR_DATA8(0x0F); 
	LCD_WR_DATA8(0x18); 
	LCD_WR_DATA8(0x2F); 
	LCD_WR_DATA8(0x28); 
	LCD_WR_DATA8(0x20); 
	LCD_WR_DATA8(0x22); 
	LCD_WR_DATA8(0x1F); 
	LCD_WR_DATA8(0x1B); 
	LCD_WR_DATA8(0x23); 
	LCD_WR_DATA8(0x37); 
	LCD_WR_DATA8(0x00); 	
	LCD_WR_DATA8(0x07); 
	LCD_WR_DATA8(0x02); 
	LCD_WR_DATA8(0x10); 

	LCD_WR_REG(0xE1); 
	LCD_WR_DATA8(0x0F); 
	LCD_WR_DATA8(0x1B); 
	LCD_WR_DATA8(0x0F); 
	LCD_WR_DATA8(0x17); 
	LCD_WR_DATA8(0x33); 
	LCD_WR_DATA8(0x2C); 
	LCD_WR_DATA8(0x29); 
	LCD_WR_DATA8(0x2E); 
	LCD_WR_DATA8(0x30); 
	LCD_WR_DATA8(0x30); 
	LCD_WR_DATA8(0x39); 
	LCD_WR_DATA8(0x3F); 
	LCD_WR_DATA8(0x00); 
	LCD_WR_DATA8(0x07); 
	LCD_WR_DATA8(0x03); 
	LCD_WR_DATA8(0x10); 

	LCD_WR_REG(0x2a);
	LCD_WR_DATA8(0x00);
	LCD_WR_DATA8(0x00 + 2);
	LCD_WR_DATA8(0x00);
	LCD_WR_DATA8(0x80 + 2);

	LCD_WR_REG(0x2b);
	LCD_WR_DATA8(0x00);
	LCD_WR_DATA8(0x00 + 1);
	LCD_WR_DATA8(0x00);
	LCD_WR_DATA8(0x80 + 1);

	LCD_WR_REG(0xF0); //Enable test command  
	LCD_WR_DATA8(0x01); 

	LCD_WR_REG(0xF6); //Disable ram power save mode 
	LCD_WR_DATA8(0x00); 

	LCD_WR_REG(0x3A); //65k mode 
	LCD_WR_DATA8(0x05); 

	LCD_WR_REG(0x29);//Display on
}
/*******************************************************************************
 ?????????UI????
*******************************************************************************/

/******************************************************************************
      ????????????????????????
      ????????xsta,ysta   ???????
                xend,yend   ???????
								color       ????????
      ???????  ??
******************************************************************************/
void LCD_Fill(unsigned int xsta,unsigned int ysta,unsigned int xend,unsigned int yend,unsigned int color)
{
	unsigned int i,j;
	LCD_Address_Set(xsta,ysta,xend-1,yend-1);//?????????Χ
	for(i=ysta;i<yend;i++)
	{
		for(j=xsta;j<xend;j++)
		{
			LCD_WR_DATA(color);
		}
	}
}

/******************************************************************************
      ??????????????λ?????
      ????????x,y ????????
                color ??????
      ???????  ??
******************************************************************************/
void LCD_DrawPoint(unsigned int x,unsigned int y,unsigned int color)
{
	LCD_Address_Set(x,y,x,y);//???ù??λ??
	LCD_WR_DATA(color);
}


/******************************************************************************
      ?????????????
      ????????x1,y1   ???????
                x2,y2   ???????
                color   ??????
      ???????  ??
******************************************************************************/
void LCD_DrawLine(unsigned int x1,unsigned int y1,unsigned int x2,unsigned int y2,unsigned int color)
{
	unsigned int t;
	int xerr=0,yerr=0,delta_x,delta_y,distance;
	int incx,incy,uRow,uCol;
	delta_x=x2-x1; //????????????
	delta_y=y2-y1;
	uRow=x1;//???????????
	uCol=y1;
	if(delta_x>0)incx=1; //???????????
	else if (delta_x==0)incx=0;//?????
	else {incx=-1;delta_x=-delta_x;}
	if(delta_y>0)incy=1;
	else if (delta_y==0)incy=0;//????
	else {incy=-1;delta_y=-delta_y;}
	if(delta_x>delta_y)distance=delta_x; //????????????????
	else distance=delta_y;
	for(t=0;t<distance+1;t++)
	{
		LCD_DrawPoint(uRow,uCol,color);//????
		xerr+=delta_x;
		yerr+=delta_y;
		if(xerr>distance)
		{
			xerr-=distance;
			uRow+=incx;
		}
		if(yerr>distance)
		{
			yerr-=distance;
			uCol+=incy;
		}
	}
}

//????????
void LCD_DrawVerrticalLine(int x, int y1, int y2, unsigned int color)
{
	int i;
	LCD_Address_Set(x, y1, x, y1 + y2);
	for(i=y1; i <= y1 + y2; i++)
	{
		LCD_WR_DATA(color);
	}

}
/******************************************************************************
      ???????????????
      ????????x1,y1   ???????
                x2,y2   ???????
                color   ???ε????
      ???????  ??
******************************************************************************/
void LCD_DrawRectangle(unsigned int x1, unsigned int y1, unsigned int x2, unsigned int y2,unsigned int color)
{
	LCD_DrawLine(x1,y1,x2,y1,color);
	LCD_DrawLine(x1,y1,x1,y2,color);
	LCD_DrawLine(x1,y2,x2,y2,color);
	LCD_DrawLine(x2,y1,x2,y2,color);
}


/******************************************************************************
      ????????????
      ????????x0,y0   ???????
                r       ??
                color   ??????
      ???????  ??
******************************************************************************/
void Draw_Circle(unsigned int x0,unsigned int y0,unsigned char r,unsigned int color)
{
	int a,b;
	a=0;b=r;
	while(a<=b)
	{
		LCD_DrawPoint(x0-b,y0-a,color);             //3
		LCD_DrawPoint(x0+b,y0-a,color);             //0
		LCD_DrawPoint(x0-a,y0+b,color);             //1
		LCD_DrawPoint(x0-a,y0-b,color);             //2
		LCD_DrawPoint(x0+b,y0+a,color);             //4
		LCD_DrawPoint(x0+a,y0-b,color);             //5
		LCD_DrawPoint(x0+a,y0+b,color);             //6
		LCD_DrawPoint(x0-b,y0+a,color);             //7
		a++;
		if((a*a+b*b)>(r*r))//?ж????????????
		{
			b--;
		}
	}
}

void Drawarc(int x,int y,int a,int b,unsigned int r,unsigned int c)
{
    int x_tp, y_tp;
    int d; // Decision variable

    // Start with the top and bottom rows of the circle
    for (x_tp = 0; x_tp <= r; x_tp++) {
        // Calculate the corresponding y values
        y_tp = (int)sqrt(r * r - x_tp * x_tp);

        // Draw the horizontal lines from the circle edge to the center
        for (int i = x_tp; i >= -x_tp; i--) {
            LCD_DrawPoint(x + i, y - y_tp, c);
            LCD_DrawPoint(x + i, y + y_tp, c);
        }
    }

    // Now fill the rest of the circle
    d = 3 - 2 * r;
    while (x_tp > y_tp) {
        if (d < 0) {
            d += 4 * x_tp + 6;
        } else {
            d += 4 * (x_tp - y_tp) + 10;
            y_tp++;
        }
        x_tp--;

        // Draw the horizontal lines from the circle edge to the center
        for (int i = -x_tp; i <= x_tp; i++) {
            LCD_DrawPoint(x + i, y - y_tp, c);
            LCD_DrawPoint(x + i, y + y_tp, c);
        }

        // Draw the vertical lines from the circle edge to the center
        for (int i = -y_tp; i <= y_tp; i++) {
            LCD_DrawPoint(x + x_tp, y + i, c);
            LCD_DrawPoint(x - x_tp, y + i, c);
        }
    }
}

void LCD_ArcRect(unsigned int xsta,unsigned int ysta,unsigned int xend,unsigned int yend,unsigned int color)
{

	int r = 4;
	//????????
	LCD_DrawLine(xsta+r,ysta,xend-r,ysta,color);
	LCD_DrawLine(xsta,ysta+r,xsta,yend-r,color);
	LCD_DrawLine(xsta+r,yend,xend-r,yend,color);
	LCD_DrawLine(xend,ysta+r,xend,yend-r,color);

	//?????????
	Drawarc(xsta+r,ysta+r,90,180,r,color);//????
	Drawarc(xend-r,ysta+r,0,90,r,color);//????
	Drawarc(xsta+r,yend-r,180,270,r,color);//????
	Drawarc(xend-r,yend-r,270,360,r,color);//????

	//???????????
	LCD_Fill(xsta+r,ysta,xend-r,ysta+r,color);//??
	LCD_Fill(xend-r,ysta+r,xend,yend-r,color);//??
	LCD_Fill(xsta+r,yend-r,xend-r,yend,color);//??
	LCD_Fill(xsta,ysta+r,xsta+r,yend-r,color);//??
	LCD_Fill(xsta+r,ysta+r,xend-r,yend-r,color);//??

}


/******************************************************************************
      ??????????????????????
      ????????x,y???????
                *s ??????????
                fc ??????
                bc ???????
                sizey ??? ??? 16 24 32
                mode:  0???????  1??????
      ???????  ??
******************************************************************************/
void LCD_ShowChinese(unsigned int x,unsigned int y,unsigned char *s,unsigned int fc,unsigned int bc,unsigned char sizey,unsigned char mode)
{
	while(*s!=0)
	{
		if(*s >= 128)
		{
			if(sizey==12) LCD_ShowChinese12x12(x,y,s,fc,bc,sizey,mode);
			else if(sizey==16) LCD_ShowChinese16x16(x,y,s,fc,bc,sizey,mode);
			else if(sizey==24) LCD_ShowChinese24x24(x,y,s,fc,bc,sizey,mode);
			else if(sizey==32) LCD_ShowChinese32x32(x,y,s,fc,bc,sizey,mode);
			else return;
			s+=2;
			x+=sizey;
		}
		else
		{
			LCD_ShowChar(x,y,*s,fc,bc,sizey,mode);
			s+=1;
			x+=(sizey/2);
		}
	}
}

/******************************************************************************
      ????????????????12x12????
      ????????x,y???????
                *s ?????????
                fc ??????
                bc ???????
                sizey ???
                mode:  0???????  1??????
      ???????  ??
******************************************************************************/
void LCD_ShowChinese12x12(unsigned int x,unsigned int y,unsigned char *s,unsigned int fc,unsigned int bc,unsigned char sizey,unsigned char mode)
{
	unsigned char i,j,m=0;
	unsigned int k;
	unsigned int HZnum;//???????
	unsigned int TypefaceNum;//?????????????С
	unsigned int x0=x;
	TypefaceNum=(sizey/8+((sizey%8)?1:0))*sizey;

	HZnum=sizeof(tfont12)/sizeof(typFNT_GB12);	//?????????
	for(k=0;k<HZnum;k++)
	{
		if((tfont12[k].Index[0]==*(s))&&(tfont12[k].Index[1]==*(s+1)))
		{
			LCD_Address_Set(x,y,x+sizey-1,y+sizey-1);
			for(i=0;i<TypefaceNum;i++)
			{
				for(j=0;j<8;j++)
				{
					if(!mode)//???????
					{
						if(tfont12[k].Msk[i]&(0x01<<j))LCD_WR_DATA(fc);
						else LCD_WR_DATA(bc);
						m++;
						if(m%sizey==0)
						{
							m=0;
							break;
						}
					}
					else//??????
					{
						if(tfont12[k].Msk[i]&(0x01<<j))	LCD_DrawPoint(x,y,fc);//???????
						x++;
						if((x-x0)==sizey)
						{
							x=x0;
							y++;
							break;
						}
					}
				}
			}
		}
		continue;  //??????????????????????????????????????????????
	}
}

/******************************************************************************
      ????????????????16x16????
      ????????x,y???????
                *s ?????????
                fc ??????
                bc ???????
                sizey ???
                mode:  0???????  1??????
      ???????  ??
******************************************************************************/
void LCD_ShowChinese16x16(unsigned int x,unsigned int y,unsigned char *s,unsigned int fc,unsigned int bc,unsigned char sizey,unsigned char mode)
{
	unsigned char i,j,m=0;
	unsigned int k;
	unsigned int HZnum;//???????
	unsigned int TypefaceNum;//?????????????С
	unsigned int x0=x;
  TypefaceNum=(sizey/8+((sizey%8)?1:0))*sizey;//32
	HZnum=sizeof(tfont16)/sizeof(typFNT_GB16);	//?????????
	for(k=0;k<HZnum;k++)
	{
		if ((tfont16[k].Index[0]==*(s))&&(tfont16[k].Index[1]==*(s+1)) )
		{
			LCD_Address_Set(x,y,x+sizey-1,y+sizey-1);
			for(i=0;i<TypefaceNum;i++)
			{
				for(j=0;j<8;j++)
				{
					if(!mode)//???????
					{
						if(tfont16[k].Msk[i]&(0x01<<j))LCD_WR_DATA(fc);
						else LCD_WR_DATA(bc);
						m++;
						if(m%sizey==0)
						{
							m=0;
							break;
						}
					}
					else//??????
					{
						if(tfont16[k].Msk[i]&(0x01<<j))	LCD_DrawPoint(x,y,fc);//???????
						x++;
						if((x-x0)==sizey)
						{
							x=x0;
							y++;
							break;
						}
					}
				}
			}
		}
		continue;  //??????????????????????????????????????????????
	}
}


/******************************************************************************
      ????????????????24x24????
      ????????x,y???????
                *s ?????????
                fc ??????
                bc ???????
                sizey ???
                mode:  0???????  1??????
      ???????  ??
******************************************************************************/
void LCD_ShowChinese24x24(unsigned int x,unsigned int y,unsigned char *s,unsigned int fc,unsigned int bc,unsigned char sizey,unsigned char mode)
{
	unsigned char i,j,m=0;
	unsigned int k;
	unsigned int HZnum;//???????
	unsigned int TypefaceNum;//?????????????С
	unsigned int x0=x;
	TypefaceNum=(sizey/8+((sizey%8)?1:0))*sizey;
	HZnum=sizeof(tfont24)/sizeof(typFNT_GB24);	//?????????
	for(k=0;k<HZnum;k++)
	{
		if ((tfont24[k].Index[0]==*(s))&&(tfont24[k].Index[1]==*(s+1)))
		{
			LCD_Address_Set(x,y,x+sizey-1,y+sizey-1);
			for(i=0;i<TypefaceNum;i++)
			{
				for(j=0;j<8;j++)
				{
					if(!mode)//???????
					{
						if(tfont24[k].Msk[i]&(0x01<<j))LCD_WR_DATA(fc);
						else LCD_WR_DATA(bc);
						m++;
						if(m%sizey==0)
						{
							m=0;
							break;
						}
					}
					else//??????
					{
						if(tfont24[k].Msk[i]&(0x01<<j))	LCD_DrawPoint(x,y,fc);//???????
						x++;
						if((x-x0)==sizey)
						{
							x=x0;
							y++;
							break;
						}
					}
				}
			}
		}
		continue;  //??????????????????????????????????????????????
	}
}

/******************************************************************************
      ????????????????32x32????
      ????????x,y???????
                *s ?????????
                fc ??????
                bc ???????
                sizey ???
                mode:  0???????  1??????
      ???????  ??
******************************************************************************/
void LCD_ShowChinese32x32(unsigned int x,unsigned int y,unsigned char *s,unsigned int fc,unsigned int bc,unsigned char sizey,unsigned char mode)
{
	unsigned char i,j,m=0;
	unsigned int k;
	unsigned int HZnum;//???????
	unsigned int TypefaceNum;//?????????????С
	unsigned int x0=x;
	TypefaceNum=(sizey/8+((sizey%8)?1:0))*sizey;
	HZnum=sizeof(tfont32)/sizeof(typFNT_GB32);	//?????????
	for(k=0;k<HZnum;k++)
	{
		if ((tfont32[k].Index[0]==*(s))&&(tfont32[k].Index[1]==*(s+1)))
		{
			LCD_Address_Set(x,y,x+sizey-1,y+sizey-1);
			for(i=0;i<TypefaceNum;i++)
			{
				for(j=0;j<8;j++)
				{
					if(!mode)//???????
					{
						if(tfont32[k].Msk[i]&(0x01<<j))LCD_WR_DATA(fc);
						else LCD_WR_DATA(bc);
						m++;
						if(m%sizey==0)
						{
							m=0;
							break;
						}
					}
					else//??????
					{
						if(tfont32[k].Msk[i]&(0x01<<j))	LCD_DrawPoint(x,y,fc);//???????
						x++;
						if((x-x0)==sizey)
						{
							x=x0;
							y++;
							break;
						}
					}
				}
			}
		}
		continue;  //??????????????????????????????????????????????
	}
}


/******************************************************************************
      ???????????????????
      ????????x,y???????
                num ?????????
                fc ??????
                bc ???????
                sizey ???
                mode:  0???????  1??????
      ???????  ??
******************************************************************************/
void LCD_ShowChar(unsigned int x,unsigned int y,unsigned char num,unsigned int fc,unsigned int bc,unsigned char sizey,unsigned char mode)
{
	unsigned char temp,sizex,t,m=0;
	unsigned int i,TypefaceNum;//?????????????С
	unsigned int x0=x;
	sizex=sizey/2;
	TypefaceNum=(sizex/8+((sizex%8)?1:0))*sizey;
	num=num-' ';    //?????????
	LCD_Address_Set(x,y,x+sizex-1,y+sizey-1);  //???ù??λ??
	for(i=0;i<TypefaceNum;i++)
	{
		if(sizey==12)temp=ascii_1206[num][i];		       //????6x12????
		else if(sizey==16)temp=ascii_1608[num][i];		 //????8x16????
		else if(sizey==24)temp=ascii_2412[num][i];		 //????12x24????
		else if(sizey==32)temp=ascii_3216[num][i];		 //????16x32????
		else return;
		for(t=0;t<8;t++)
		{
			if(!mode)//???????
			{
				if(temp&(0x01<<t))LCD_WR_DATA(fc);
				else LCD_WR_DATA(bc);
				m++;
				if(m%sizex==0)
				{
					m=0;
					break;
				}
			}
			else//??????
			{
				if(temp&(0x01<<t))LCD_DrawPoint(x,y,fc);//???????
				x++;
				if((x-x0)==sizex)
				{
					x=x0;
					y++;
					break;
				}
			}
		}
	}
}


/******************************************************************************
      ?????????????????
      ????????x,y???????
                *p ???????????
                fc ??????
                bc ???????
                sizey ???
                mode:  0???????  1??????
      ???????  ??
******************************************************************************/
void LCD_ShowString(unsigned int x,unsigned int y,const unsigned char *p,unsigned int fc,unsigned int bc,unsigned char sizey,unsigned char mode)
{
	while(*p!='\0')
	{
		LCD_ShowChar(x,y,*p,fc,bc,sizey,mode);
		x+=sizey/2;
		p++;
	}
}


/******************************************************************************
      ????????????????
      ????????m??????n???
      ???????  ??
******************************************************************************/
unsigned int mypow(unsigned char m,unsigned char n)
{
	unsigned int result=1;
	while(n--)result*=m;
	return result;
}


/******************************************************************************
      ????????????????????
      ????????x,y???????
                num ????????????
                len ??????λ??
                fc ??????
                bc ???????
                sizey ???
      ???????  ??
******************************************************************************/
void LCD_ShowIntNum(unsigned int x,unsigned int y,unsigned int num,unsigned char len,unsigned int fc,unsigned int bc,unsigned char sizey)
{
	unsigned char t,temp;
	unsigned char enshow=0;
	unsigned char sizex=sizey/2;
	for(t=0;t<len;t++)
	{
		temp=(num/mypow(10,len-t-1))%10;
		if(enshow==0&&t<(len-1))
		{
			if(temp==0)
			{
				LCD_ShowChar(x+t*sizex,y,' ',fc,bc,sizey,0);
				continue;
			}else enshow=1;

		}
	 	LCD_ShowChar(x+t*sizex,y,temp+48,fc,bc,sizey,0);
	}
}


/******************************************************************************
      ??????????????λС??????
      ????????x,y???????
                num ????С??????
                len ??????λ??
                fc ??????
                bc ???????
                sizey ???
      ???????  ??
******************************************************************************/
void LCD_ShowFloatNum1(unsigned int x,unsigned int y,float num,unsigned char len,unsigned int fc,unsigned int bc,unsigned char sizey)
{
	unsigned char t,temp,sizex;
	unsigned int num1;
	sizex=sizey/2;
	num1=num*100;
	for(t=0;t<len;t++)
	{
		temp=(num1/mypow(10,len-t-1))%10;
		if(t==(len-2))
		{
			LCD_ShowChar(x+(len-2)*sizex,y,'.',fc,bc,sizey,0);
			t++;
			len+=1;
		}
	 	LCD_ShowChar(x+t*sizex,y,temp+48,fc,bc,sizey,0);
	}
}


/******************************************************************************
      ??????????????
      ????????x,y???????
                length ??????
                width  ?????
                pic[]  ??????
      ???????  ??
******************************************************************************/
void LCD_ShowPicture(unsigned int x,unsigned int y,unsigned int length,unsigned int width,const unsigned char pic[])
{
	unsigned int i,j;
	uint32_t k=0;
	LCD_Address_Set(x,y,x+length-1,y+width-1);
	for(i=0;i<length;i++)
	{
		for(j=0;j<width;j++)
		{
			LCD_WR_DATA8(pic[k*2]);
			LCD_WR_DATA8(pic[k*2+1]);
			k++;
		}
	}
}