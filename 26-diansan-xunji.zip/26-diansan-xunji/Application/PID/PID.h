﻿#ifndef __PID_H
#define __PID_H

#include "ti_msp_dl_config.h"

// PID 结构体定义
typedef struct {
    float Kp;           // 比例系数
    float Ki;           // 积分系数
    float Kd;           // 微分系数

    float target;       // 目标值
    float actual;       // 实际测量值

    float error;        // 当前偏差
    float prev_error;   // 上一次偏差
    float integral;     // 积分累加值

    float output;       // PID 输出值
    float max_output;   // 输出上限（限幅）
    float max_integral; // 积分上限（防止积分饱和）
} PID_Controller;

void PID_Init(PID_Controller *pid, float Kp, float Ki, float Kd, float max_outpu,float max_integral);
float PID_Compute(PID_Controller *pid, float target, float actual);
void System_PID_Init(void);
float Cascade_PID_Control(float target_position, float current_position, float current_velocity);

#endif // __PID_H