﻿#ifndef __LED_H
#define __LED_H

#include "ti_msp_dl_config.h"

void LED_off(void);
void LED_on(void);

#endif // __LED_H