﻿#include "LED.h"

// 关闭LED灯（高电平关闭）
void LED_off(void)
{
    DL_GPIO_setPins(LED_PORT, LED_PIN_22_PIN);
}

// 打开LED灯（低电平打开）
void LED_on(void)
{
    DL_GPIO_clearPins(LED_PORT, LED_PIN_22_PIN);
}
