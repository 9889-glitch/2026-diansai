#ifndef _ENCODER_H_
#define _ENCODER_H_

#include "ti_msp_dl_config.h"
#include "stdint.h"

typedef enum {
    FORWARD,  // 正向旋转
    REVERSAL  // 反向旋转
} ENCODER_DIR;

typedef struct {
    volatile int32_t count;          // 编码器计数值
    volatile int32_t speed;          // 编码器速度值（单位时间内的计数值）
    ENCODER_DIR dir;                 // 编码器方向
} ENCODER_RES;

// 编码器初始化
void encoder_init(void);

// 获取电机A编码器计数值
int32_t encoder_get_countA(void);

// 获取电机B编码器计数值
int32_t encoder_get_countB(void);

// 获取电机A编码器速度
int32_t encoder_get_speedA(void);

// 获取电机B编码器速度
int32_t encoder_get_speedB(void);

// 清零编码器计数值
void encoder_clear_count(void);

// 获取编码器方向
ENCODER_DIR encoder_get_dirA(void);
ENCODER_DIR encoder_get_dirB(void);

#endif
