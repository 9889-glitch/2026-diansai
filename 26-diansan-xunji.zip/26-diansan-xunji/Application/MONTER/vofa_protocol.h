﻿#ifndef _VOFA_PROTOCOL_H_
#define _VOFA_PROTOCOL_H_

#include "ti_msp_dl_config.h"

// VOFA+ firewater协议格式：
// 帧头(1字节) + 通道数(1字节) + 数据(4字节*通道数) + 校验(1字节)
// 帧头: 0xA5
// 通道数: n
// 数据: float类型，小端序
// 校验: 所有字节异或

#define VOFA_FRAME_HEADER 0xA5

// 发送firewater协议数据
void vofa_send_firewater(uint8_t channels, float *data);

#endif