﻿#include "encoder.h"

// 编码器累积计数值（持续累加，不清零）
volatile int32_t Encoder_CountA = 0;  // 电机A编码器计数值
volatile int32_t Encoder_CountB = 0;  // 电机B编码器计数值

// 编码器速度值（定时器中断周期内的计数值）
volatile int32_t Encoder_SpeedA = 0;
volatile int32_t Encoder_SpeedB = 0;

// 临时计数值（用于计算速度）
volatile int32_t Encoder_TempA = 0;
volatile int32_t Encoder_TempB = 0;

// 编码器初始化
void encoder_init(void)
{
    // 清除编码器中断标志位
    NVIC_ClearPendingIRQ(ENCODER_GPIOA_INT_IRQN);
    NVIC_ClearPendingIRQ(ENCODER_GPIOB_INT_IRQN);
    
    // 使能编码器中断
    NVIC_EnableIRQ(ENCODER_GPIOA_INT_IRQN);
    NVIC_EnableIRQ(ENCODER_GPIOB_INT_IRQN);
    
    // 打开LED指示编码器初始化完成
    DL_GPIO_setPins(LED_PORT, LED_PIN_22_PIN);
}

// 获取电机A编码器计数值
int32_t encoder_get_countA(void)
{
    return Encoder_CountA;
}

// 获取电机B编码器计数值
int32_t encoder_get_countB(void)
{
    return Encoder_CountB;
}

// 获取电机A编码器速度
int32_t encoder_get_speedA(void)
{
    return Encoder_SpeedA;
}

// 获取电机B编码器速度
int32_t encoder_get_speedB(void)
{
    return Encoder_SpeedB;
}

// 清零编码器计数值
void encoder_clear_count(void)
{
    Encoder_CountA = 0;
    Encoder_CountB = 0;
}

// 获取电机A编码器方向
ENCODER_DIR encoder_get_dirA(void)
{
    return (Encoder_SpeedA >= 0) ? FORWARD : REVERSAL;
}

// 获取电机B编码器方向
ENCODER_DIR encoder_get_dirB(void)
{
    return (Encoder_SpeedB >= 0) ? FORWARD : REVERSAL;
}

// GROUP1中断处理函数 - 处理GPIOA和GPIOB的中断
// MSPM0的GPIOA和GPIOB中断都属于GROUP1中断组
void GROUP1_IRQHandler(void)
{
    // ============ 电机A编码器（PA15=E1A，PA16=E1B）============
    uint32_t InterA_Flag = DL_GPIO_getEnabledInterruptStatus(ENCODER_PIN_1_A_PORT,
                                                          ENCODER_PIN_1_A_PIN);
    
    if ((InterA_Flag & ENCODER_PIN_1_A_PIN) == ENCODER_PIN_1_A_PIN)
    {
        // 闪烁LED表示中断触发
        DL_GPIO_togglePins(LED_PORT, LED_PIN_22_PIN);
        
        // E1A上升沿，读取B相判断方向
        if (DL_GPIO_readPins(ENCODER_PIN_1_A_PORT, ENCODER_PIN_1_B_PIN))
        {
            // E1B=1，电机A反向旋转
            Encoder_CountA--;
            Encoder_TempA--;
        }
        else
        {
            // E1B=0，电机A正向旋转
            Encoder_CountA++;
            Encoder_TempA++;
        }
        
        // 清除中断标志位
        DL_GPIO_clearInterruptStatus(ENCODER_PIN_1_A_PORT, ENCODER_PIN_1_A_PIN);
    }
    
    // ============ 电机B编码器（PB4=E2A，PB5=E2B）============
    uint32_t InterB_Flag = DL_GPIO_getEnabledInterruptStatus(ENCODER_PIN_2_A_PORT,
                                                          ENCODER_PIN_2_A_PIN);
    
    if ((InterB_Flag & ENCODER_PIN_2_A_PIN) == ENCODER_PIN_2_A_PIN)
    {
        // 闪烁LED表示中断触发
        DL_GPIO_togglePins(LED_PORT, LED_PIN_22_PIN);
        
        // E2A上升沿，读取B相判断方向
        if (DL_GPIO_readPins(ENCODER_PIN_2_A_PORT, ENCODER_PIN_2_B_PIN))
        {
            // E2B=1，电机B反向旋转
            Encoder_CountB--;
            Encoder_TempB--;
        }
        else
        {
            // E2B=0，电机B正向旋转
            Encoder_CountB++;
            Encoder_TempB++;
        }
        
        // 清除中断标志位
        DL_GPIO_clearInterruptStatus(ENCODER_PIN_2_A_PORT, ENCODER_PIN_2_A_PIN);
    }
}

// 定时器中断处理函数 - 用于计算速度
void TIMER_TICK_INST_IRQHandler(void)
{
    if (DL_TimerA_getPendingInterrupt(TIMER_TICK_INST) == DL_TIMER_IIDX_ZERO)
    {
        // 获取当前周期内的计数值作为速度
        Encoder_SpeedA = Encoder_TempA;
        Encoder_SpeedB = Encoder_TempB;
        
        // 清零临时计数值，准备下一个周期
        Encoder_TempA = 0;
        Encoder_TempB = 0;
        
        // 清除定时器中断标志
        DL_TimerA_clearInterruptStatus(TIMER_TICK_INST, DL_TIMER_IIDX_ZERO);
    }
}
