﻿#include "vofa_protocol.h"
#include "board.h"

// 发送单个字节
static void vofa_send_byte(uint8_t byte)
{
    while( DL_UART_Main_isTXFIFOFull(UART_0_INST) == true );
    DL_UART_Main_transmitData(UART_0_INST, byte);
}

// 发送firewater协议数据
void vofa_send_firewater(uint8_t channels, float *data)
{
    // 帧头
    vofa_send_byte(VOFA_FRAME_HEADER);
    
    // 通道数
    vofa_send_byte(channels);
    
    // 计算校验和
    uint8_t checksum = VOFA_FRAME_HEADER ^ channels;
    
    // 发送数据（小端序）
    for (uint8_t i = 0; i < channels; i++) {
        uint8_t *p = (uint8_t *)&data[i];
        for (uint8_t j = 0; j < 4; j++) {
            vofa_send_byte(p[j]);
            checksum ^= p[j];
        }
    }
    
    // 发送校验和
    vofa_send_byte(checksum);
}