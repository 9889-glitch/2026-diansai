﻿#include "TB6612.h"
#include "board.h"

/******************************************************************
 * 函 数 名 称：TB6612_Motor_Stop
 * 函 数 说 明：A端和B端电机停止
 * 函 数 形 参：无
 * 函 数 返 回：无
 * 作       者：LCKFB
 * 备       注：无
******************************************************************/
void TB6612_Motor_Stop(void)
{
    AIN1_OUT(1);
    AIN2_OUT(1);
    BIN1_OUT(1);
    BIN2_OUT(1);
    // STBY必须为高电平才能使TB6612工作
    STBY_OUT(1);
}

/******************************************************************
 * 函 数 名 称：AO_Control
 * 函 数 说 明：A端口电机控制
 * 函 数 形 参：dir旋转方向 1正转0反转   speed旋转速度，范围（0 ~ 999）
 * 函 数 返 回：无
 * 作       者：LCKFB
 * 备       注：speed范围0-1000
******************************************************************/
void AO_Control(uint8_t dir, uint32_t speed)
{
    if(speed > 999 || dir > 1)
    {
        lc_printf("\nAO_Control参数错误！！！\r\n");
        return;
    }

    // STBY必须为高电平才能使TB6612工作
    STBY_OUT(1);

    if( dir == 1 )
    {
        AIN1_OUT(1);
        AIN2_OUT(0);
    }
    else
    {
        AIN1_OUT(0);
        AIN2_OUT(1);
    }

    DL_TimerG_setCaptureCompareValue(PWMA_INST, speed, GPIO_PWMA_C0_IDX);
}




/******************************************************************
 * 函 数 名 称：BO_Control
 * 函 数 说 明：B端口电机控制
 * 函 数 形 参：dir旋转方向 1正转0反转   speed旋转速度，范围（0 ~ 999）
 * 函 数 返 回：无
 * 作       者：LCKFB
 * 备       注：speed范围0-1000
******************************************************************/
void BO_Control(uint8_t dir, uint32_t speed)
{
    if(speed > 999 || dir > 1)
    {
        lc_printf("\nBO_Control参数错误！！！\r\n");
        return;
    }

    // STBY必须为高电平才能使TB6612工作
    STBY_OUT(1);

    if( dir == 1 )
    {
        BIN1_OUT(0);
        BIN2_OUT(1);
    }
    else
    {
        BIN1_OUT(1);
        BIN2_OUT(0);
    }

    DL_TimerA_setCaptureCompareValue(PWMB_INST, speed, GPIO_PWMB_C1_IDX);
}
