################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Application/PID/PID.c \
../Application/PID/distance.c 

C_DEPS += \
./Application/PID/PID.d \
./Application/PID/distance.d 

OBJS += \
./Application/PID/PID.o \
./Application/PID/distance.o 

OBJS__QUOTED += \
"Application\PID\PID.o" \
"Application\PID\distance.o" 

C_DEPS__QUOTED += \
"Application\PID\PID.d" \
"Application\PID\distance.d" 

C_SRCS__QUOTED += \
"../Application/PID/PID.c" \
"../Application/PID/distance.c" 


