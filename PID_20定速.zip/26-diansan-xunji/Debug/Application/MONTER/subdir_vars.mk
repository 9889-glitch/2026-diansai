################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Application/MONTER/TB6612.c \
../Application/MONTER/board.c \
../Application/MONTER/encoder.c \
../Application/MONTER/nrf24l01_uart.c \
../Application/MONTER/vofa_protocol.c 

C_DEPS += \
./Application/MONTER/TB6612.d \
./Application/MONTER/board.d \
./Application/MONTER/encoder.d \
./Application/MONTER/nrf24l01_uart.d \
./Application/MONTER/vofa_protocol.d 

OBJS += \
./Application/MONTER/TB6612.o \
./Application/MONTER/board.o \
./Application/MONTER/encoder.o \
./Application/MONTER/nrf24l01_uart.o \
./Application/MONTER/vofa_protocol.o 

OBJS__QUOTED += \
"Application\MONTER\TB6612.o" \
"Application\MONTER\board.o" \
"Application\MONTER\encoder.o" \
"Application\MONTER\nrf24l01_uart.o" \
"Application\MONTER\vofa_protocol.o" 

C_DEPS__QUOTED += \
"Application\MONTER\TB6612.d" \
"Application\MONTER\board.d" \
"Application\MONTER\encoder.d" \
"Application\MONTER\nrf24l01_uart.d" \
"Application\MONTER\vofa_protocol.d" 

C_SRCS__QUOTED += \
"../Application/MONTER/TB6612.c" \
"../Application/MONTER/board.c" \
"../Application/MONTER/encoder.c" \
"../Application/MONTER/nrf24l01_uart.c" \
"../Application/MONTER/vofa_protocol.c" 


