################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
build-1329250473: ../empty.syscfg
	@echo 'SysConfig - building file: "$<"'
	"C:/TI/sysconfig_1.26.2/sysconfig_cli.bat" -s "D:/ti/ccs2050/mspm0_sdk_2_11_00_07/.metadata/product.json" --script "D:/TI project/workspace_ccstheia/26-diansan-xunji/empty.syscfg" -o "." --compiler ticlang
	@echo 'Finished building: "$<"'
	@echo ' '

device_linker.cmd: build-1329250473 ../empty.syscfg
device.opt: build-1329250473
device.cmd.genlibs: build-1329250473
ti_msp_dl_config.c: build-1329250473
ti_msp_dl_config.h: build-1329250473
Event.dot: build-1329250473

%.o: ./%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Arm Compiler - building file: "$<"'
	"D:/ti/ccs2050/ccs/tools/compiler/ti-cgt-armllvm_4.0.4.LTS/bin/tiarmclang.exe" -c @"device.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -O2 -I"D:/TI project/workspace_ccstheia/26-diansan-xunji/Application/KEY" -I"D:/TI project/workspace_ccstheia/26-diansan-xunji/Application/PID" -I"D:/TI project/workspace_ccstheia/26-diansan-xunji/Application/MONTER" -I"D:/TI project/workspace_ccstheia/26-diansan-xunji/Application/LCD" -I"D:/TI project/workspace_ccstheia/26-diansan-xunji/Application/LED" -I"D:/TI project/workspace_ccstheia/26-diansan-xunji/Application" -I"D:/TI project/workspace_ccstheia/26-diansan-xunji" -I"D:/TI project/workspace_ccstheia/26-diansan-xunji/Debug" -I"D:/ti/ccs2050/mspm0_sdk_2_11_00_07/source/third_party/CMSIS/Core/Include" -I"D:/ti/ccs2050/mspm0_sdk_2_11_00_07/source" -g -Wall -MMD -MP -MF"$(basename $(<F)).d_raw" -MT"$(@)"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '

startup_mspm0g350x_ticlang.o: D:/ti/ccs2050/mspm0_sdk_2_11_00_07/source/ti/devices/msp/m0p/startup_system_files/ticlang/startup_mspm0g350x_ticlang.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Arm Compiler - building file: "$<"'
	"D:/ti/ccs2050/ccs/tools/compiler/ti-cgt-armllvm_4.0.4.LTS/bin/tiarmclang.exe" -c @"device.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -O2 -I"D:/TI project/workspace_ccstheia/26-diansan-xunji/Application/KEY" -I"D:/TI project/workspace_ccstheia/26-diansan-xunji/Application/PID" -I"D:/TI project/workspace_ccstheia/26-diansan-xunji/Application/MONTER" -I"D:/TI project/workspace_ccstheia/26-diansan-xunji/Application/LCD" -I"D:/TI project/workspace_ccstheia/26-diansan-xunji/Application/LED" -I"D:/TI project/workspace_ccstheia/26-diansan-xunji/Application" -I"D:/TI project/workspace_ccstheia/26-diansan-xunji" -I"D:/TI project/workspace_ccstheia/26-diansan-xunji/Debug" -I"D:/ti/ccs2050/mspm0_sdk_2_11_00_07/source/third_party/CMSIS/Core/Include" -I"D:/ti/ccs2050/mspm0_sdk_2_11_00_07/source" -g -Wall -MMD -MP -MF"$(basename $(<F)).d_raw" -MT"$(@)"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '

%.o: ../%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Arm Compiler - building file: "$<"'
	"D:/ti/ccs2050/ccs/tools/compiler/ti-cgt-armllvm_4.0.4.LTS/bin/tiarmclang.exe" -c @"device.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -O2 -I"D:/TI project/workspace_ccstheia/26-diansan-xunji/Application/KEY" -I"D:/TI project/workspace_ccstheia/26-diansan-xunji/Application/PID" -I"D:/TI project/workspace_ccstheia/26-diansan-xunji/Application/MONTER" -I"D:/TI project/workspace_ccstheia/26-diansan-xunji/Application/LCD" -I"D:/TI project/workspace_ccstheia/26-diansan-xunji/Application/LED" -I"D:/TI project/workspace_ccstheia/26-diansan-xunji/Application" -I"D:/TI project/workspace_ccstheia/26-diansan-xunji" -I"D:/TI project/workspace_ccstheia/26-diansan-xunji/Debug" -I"D:/ti/ccs2050/mspm0_sdk_2_11_00_07/source/third_party/CMSIS/Core/Include" -I"D:/ti/ccs2050/mspm0_sdk_2_11_00_07/source" -g -Wall -MMD -MP -MF"$(basename $(<F)).d_raw" -MT"$(@)"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '


