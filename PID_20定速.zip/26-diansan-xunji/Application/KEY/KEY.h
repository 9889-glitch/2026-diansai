﻿#ifndef __KEY_H
#define __KEY_H

#include "ti_msp_dl_config.h"
#include "mid_button.h"

// 按键事件类型
typedef enum {
    KEY_EVENT_NONE = 0,      // 无事件
    KEY_EVENT_ADD_10,        // 加10
    KEY_EVENT_SUB_10,        // 减10
    KEY_EVENT_TOGGLE_MODE,   // 切换模式
    KEY_EVENT_CONFIRM        // 确认
} KEY_EVENT_T;

// 设置当前模式（0=距离设置, 1=速度设置）
void set_app_key_current_mode(char mode);
// 获取当前模式
char get_app_key_current_mode(void);
// 获取按键事件
KEY_EVENT_T get_key_event(void);
// 按键扫描任务（必须每10ms调用一次）
void key_scan_task(void);

// 按键回调函数（兼容旧接口）
void btn_up_cb(flex_button_t *btn);
void btn_left_cb(flex_button_t *btn);
void btn_right_cb(flex_button_t *btn);
void btn_down_cb(flex_button_t *btn);

#endif // __KEY_H
