﻿#include "KEY.h"
#include "hw_key.h"

// 当前设置模式：0=距离设置, 1=速度设置
static char current_mode = 0;

// 当前按键事件
static KEY_EVENT_T key_event = KEY_EVENT_NONE;

// 按键消抖计数器
static uint16_t key_debounce[4] = {0};
// 按键上次状态
static uint8_t key_last[4] = {1, 1, 1, 1};

// 设置当前模式
void set_app_key_current_mode(char mode)
{
    current_mode = mode;
}

// 获取当前模式
char get_app_key_current_mode(void)
{
    return current_mode;
}

// 获取按键事件
KEY_EVENT_T get_key_event(void)
{
    KEY_EVENT_T event = key_event;
    key_event = KEY_EVENT_NONE;
    return event;
}

// 按键扫描（必须每10ms调用一次）
void key_scan_task(void)
{
    KEY_STATUS keys = key_scan();
    
    // 按键顺序：UP, LEFT, RIGHT, DOWN
    uint8_t key_state[4] = {keys.up, keys.left, keys.right, keys.down};
    
    for (int i = 0; i < 4; i++) {
        if (key_state[i] == 0) {  // 按键按下（低电平）
            if (key_debounce[i] < 10) {  // 消抖计数
                key_debounce[i]++;
            }
            if (key_debounce[i] >= 10 && key_last[i] == 1) {  // 消抖完成且是新按下
                key_last[i] = 0;
                switch (i) {
                    case 0: key_event = KEY_EVENT_ADD_10; break;      // UP
                    case 1: key_event = KEY_EVENT_TOGGLE_MODE; break; // LEFT
                    case 2: key_event = KEY_EVENT_CONFIRM; break;     // RIGHT
                    case 3: key_event = KEY_EVENT_SUB_10; break;      // DOWN
                }
            }
        } else {  // 按键释放（高电平）
            key_debounce[i] = 0;
            key_last[i] = 1;
        }
    }
}

// UP键回调（兼容旧接口）
void btn_up_cb(flex_button_t *btn)
{
}

// LEFT键回调（兼容旧接口）
void btn_left_cb(flex_button_t *btn)
{
}

// RIGHT键回调（兼容旧接口）
void btn_right_cb(flex_button_t *btn)
{
}

// DOWN键回调（兼容旧接口）
void btn_down_cb(flex_button_t *btn)
{
}
