﻿#ifndef _VOFA_PROTOCOL_H_
#define _VOFA_PROTOCOL_H_

#include "ti_msp_dl_config.h"

/*
 * VOFA+ FireWater 协议（文本格式）：
 * 帧格式：#data:ch0,ch1,ch2,...\r\n
 * VOFA+ 设置：协议选择 FireWater，串口 115200 8N1
 *
 * VOFA+ JustFloat 协议（二进制格式）：
 * 按通道依次发送 float32（小端），帧尾固定 4 字节：
 * 0x00, 0x00, 0x80, 0x7F
 */

/* 发送 FireWater 帧（文本格式，推荐使用） */
void vofa_send_firewater(uint8_t channels, const float *data);

/* 发送 JustFloat 帧（二进制格式） */
void vofa_send_justfloat(uint8_t channels, const float *data);

#endif
