﻿#include "nrf24l01_uart.h"
#include "board.h"

// nRF24L01无线串口发送单个字符
void nrf24l01_send_char(uint8_t ch)
{
    lc_printf("%c", ch);
}

// nRF24L01无线串口发送字符串
void nrf24l01_send_string(char* str)
{
    lc_printf("%s", str);
}

// nRF24L01无线串口发送格式化数据（类似printf）
void nrf24l01_printf(const char* format, ...)
{
    va_list args;
    va_start(args, format);
    
    char buffer[512] = {0};
    vsnprintf(buffer, sizeof(buffer), format, args);
    
    va_end(args);
    
    nrf24l01_send_string(buffer);
}

// nRF24L01无线串口发送字节数组
void nrf24l01_send_bytes(uint8_t* data, uint32_t len)
{
    for (uint32_t i = 0; i < len; i++) {
        // 使用底层UART发送函数直接发送字节
        while (DL_UART_isBusy(UART_0_INST) == true);
        DL_UART_Main_transmitData(UART_0_INST, data[i]);
    }
}

// nRF24L01无线串口发送电机数据（编码器值和速度）
// 数据格式简化，确保单次发送不超过nRF24L01的32字节单包限制
void nrf24l01_send_motor_data(int32_t countA, int32_t speedA, int32_t countB, int32_t speedB)
{
    nrf24l01_printf("A:%d,%d B:%d,%d\r\n", countA, speedA, countB, speedB);
}

// nRF24L01无线串口发送PID数据
// 数据格式简化，确保单次发送不超过nRF24L01的32字节单包限制
void nrf24l01_send_pid_data(float targetA, float currentA, float outputA,
                            float targetB, float currentB, float outputB)
{
    nrf24l01_printf("A:%.0f,%.0f,%.0f B:%.0f,%.0f,%.0f\r\n",
                    targetA, currentA, outputA, targetB, currentB, outputB);
}

// nRF24L01无线串口发送距离数据
// 数据格式：D:距离(cm),A:编码器A,B:编码器B
void nrf24l01_send_distance_data(float distance_cm, int32_t countA, int32_t countB)
{
    nrf24l01_printf("D:%.1fcm A:%d B:%d\r\n", distance_cm, countA, countB);
}
