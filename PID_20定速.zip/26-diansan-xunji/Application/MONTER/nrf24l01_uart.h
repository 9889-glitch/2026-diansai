﻿#ifndef __NRF24L01_UART_H__
#define __NRF24L01_UART_H__

#include "stdint.h"
#include "stdarg.h"
#include "stdio.h"
#include "ti_msp_dl_config.h"

// nRF24L01无线串口发送单个字符
void nrf24l01_send_char(uint8_t ch);

// nRF24L01无线串口发送字符串
void nrf24l01_send_string(char* str);

// nRF24L01无线串口发送格式化数据（类似printf）
void nrf24l01_printf(const char* format, ...);

// nRF24L01无线串口发送字节数组
void nrf24l01_send_bytes(uint8_t* data, uint32_t len);

// nRF24L01无线串口发送电机数据（编码器值和速度）
void nrf24l01_send_motor_data(int32_t countA, int32_t speedA, int32_t countB, int32_t speedB);

// nRF24L01无线串口发送PID数据
void nrf24l01_send_pid_data(float targetA, float currentA, float outputA, 
                            float targetB, float currentB, float outputB);

// nRF24L01无线串口发送距离数据
void nrf24l01_send_distance_data(float distance_cm, int32_t countA, int32_t countB);

#endif
