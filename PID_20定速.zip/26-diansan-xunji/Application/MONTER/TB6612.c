#include "TB6612.h"

/**
 * @brief A �˿ڵ������
 * @param dir   1=��ת��0=��ת
 * @param speed PWM �Ƚ�ֵ 0~999
 */
void AO_Control(uint8_t dir, uint32_t speed)
{
    if (speed > 999u) speed = 999u;

    STBY_OUT(1);  /* ȷ�� STBY Ϊ�� */

    if (dir == 1u) {
        AIN1_OUT(0);
        AIN2_OUT(1);
    } else {
        AIN1_OUT(1);
        AIN2_OUT(0);
    }

    DL_TimerG_setCaptureCompareValue(PWMA_INST, speed, GPIO_PWMA_C0_IDX);
}

/**
 * @brief B �˿ڵ������
 * @param dir   1=��ת��0=��ת
 * @param speed PWM �Ƚ�ֵ 0~999
 */
void BO_Control(uint8_t dir, uint32_t speed)
{
    if (speed > 999u) speed = 999u;

    STBY_OUT(1);  /* ȷ�� STBY Ϊ�� */

    if (dir == 1u) {
        BIN1_OUT(1);
        BIN2_OUT(0);
    } else {
        BIN1_OUT(0);
        BIN2_OUT(1);
    }

    DL_TimerA_setCaptureCompareValue(PWMB_INST, speed, GPIO_PWMB_C1_IDX);
}

/**
 * @brief ���ֹͣ����·�ƶ���
 */
void TB6612_Motor_Stop(void)
{
    DL_TimerG_setCaptureCompareValue(PWMA_INST, 0u, GPIO_PWMA_C0_IDX);
    DL_TimerA_setCaptureCompareValue(PWMB_INST, 0u, GPIO_PWMB_C1_IDX);

    AIN1_OUT(1);
    AIN2_OUT(1);
    BIN1_OUT(1);
    BIN2_OUT(1);
    STBY_OUT(1);
}
