﻿#include "vofa_protocol.h"
#include "board.h"
#include "stdio.h"
#include "string.h"

/* 发送单个字节到 UART0（VOFA+ 接板载 CH340） */
static void vofa_send_byte(uint8_t byte)
{
    while (DL_UART_Main_isTXFIFOFull(UART_0_INST) == true) {
        /* 等待发送 FIFO 有空位 */
    }
    DL_UART_Main_transmitData(UART_0_INST, byte);
}

/**
 * @brief 发送 VOFA+ FireWater 协议数据（文本格式）
 * @param channels 通道数量
 * @param data     float 数组，长度 = channels
 *
 * FireWater 协议格式：#data:ch0,ch1,ch2,...\r\n
 * VOFA+ 设置：协议选择 FireWater，串口 115200 8N1
 *
 * 通道约定（本工程）：
 *   ch0: 目标速度（编码器脉冲/20ms）
 *   ch1: 电机A实际速度
 *   ch2: 电机B实际速度
 *   ch3: 电机A PWM 输出（0-999）
 *   ch4: 电机B PWM 输出（0-999）
 */
void vofa_send_firewater(uint8_t channels, const float *data)
{
    char buf[64];
    uint8_t i;
    uint8_t len;

    /* 构建 FireWater 协议帧头 */
    len = sprintf(buf, "#data:");
    
    /* 添加各通道数据 */
    for (i = 0; i < channels; i++) {
        if (i > 0) {
            len += sprintf(buf + len, ",");
        }
        len += sprintf(buf + len, "%.2f", data[i]);
    }
    
    /* 添加帧尾 */
    len += sprintf(buf + len, "\r\n");

    /* 发送整个字符串 */
    for (i = 0; i < len; i++) {
        vofa_send_byte((uint8_t)buf[i]);
    }
}

/**
 * @brief 发送 VOFA+ JustFloat 协议数据（二进制格式）
 * @param channels 通道数量
 * @param data     float 数组，长度 = channels
 *
 * JustFloat 协议：按通道依次发送 float32（小端），帧尾固定 4 字节
 * 0x00, 0x00, 0x80, 0x7F
 */
void vofa_send_justfloat(uint8_t channels, const float *data)
{
    uint8_t i;
    uint8_t j;

    for (i = 0; i < channels; i++) {
        const uint8_t *p = (const uint8_t *)&data[i];
        for (j = 0; j < 4; j++) {
            vofa_send_byte(p[j]);
        }
    }

    vofa_send_byte(0x00u);
    vofa_send_byte(0x00u);
    vofa_send_byte(0x80u);
    vofa_send_byte(0x7Fu);
}
