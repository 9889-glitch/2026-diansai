﻿#include "distance.h"
#include "stdint.h"
#include "encoder.h"

// 距离数据全局变量
static DISTANCE_DATA g_distance_data;

// 当前校准系数
static float g_calibration_factor = DISTANCE_CALIBRATION;

// 初始化距离计算模块
void distance_init(void)
{
    // 清零所有距离数据
    g_distance_data.distance_A = 0.0f;
    g_distance_data.distance_B = 0.0f;
    g_distance_data.distance_avg = 0.0f;
    g_distance_data.count_A = 0;
    g_distance_data.count_B = 0;

    // 初始化校准系数
    g_calibration_factor = DISTANCE_CALIBRATION;
}

// 更新距离数据（根据编码器计数值计算）
void distance_update(int32_t countA, int32_t countB)
{
    // 更新编码器计数值
    g_distance_data.count_A = countA;
    g_distance_data.count_B = countB;

    // 根据编码器脉冲数计算行走距离
    // 距离 = 脉冲数 × 每脉冲距离 × 校准系数
    g_distance_data.distance_A = (float)countA * DISTANCE_PER_PULSE_MM * g_calibration_factor;
    g_distance_data.distance_B = (float)countB * DISTANCE_PER_PULSE_MM * g_calibration_factor;

    // 计算平均距离（左右轮平均）
    g_distance_data.distance_avg = (g_distance_data.distance_A + g_distance_data.distance_B) / 2.0f;
}

// 获取距离数据
DISTANCE_DATA distance_get_data(void)
{
    return g_distance_data;
}

// 清零距离数据
void distance_clear(void)
{
    // 清零距离数据
    g_distance_data.distance_A = 0.0f;
    g_distance_data.distance_B = 0.0f;
    g_distance_data.distance_avg = 0.0f;
    g_distance_data.count_A = 0;
    g_distance_data.count_B = 0;

    // 同时清零编码器计数值
    encoder_clear_count();
}

// 获取平均距离（厘米）
float distance_get_avg_cm(void)
{
    return g_distance_data.distance_avg / 10.0f;
}

// 获取平均距离（米）
float distance_get_avg_m(void)
{
    return g_distance_data.distance_avg / 1000.0f;
}

// 设置距离校准系数
void distance_set_calibration(float factor)
{
    if (factor > 0.0f) {
        g_calibration_factor = factor;
    }
}

// 获取当前校准系数
float distance_get_calibration(void)
{
    return g_calibration_factor;
}
