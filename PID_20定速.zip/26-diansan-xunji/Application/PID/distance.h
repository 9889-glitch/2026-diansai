﻿#ifndef __DISTANCE_H__
#define __DISTANCE_H__

#include "stdint.h"
#include "encoder.h"

// 距离计算相关常量
#define WHEEL_DIAMETER_MM      65.0f      // 轮胎直径（毫米）
#define ENCODER_PULSES_PER_REV 1504       // 车轮转一圈的编码器脉冲数（四倍频：单倍频约376 × 4）

// 每脉冲对应的距离（毫米）
// 计算公式：每脉冲距离 = π × 直径 / 车轮每转脉冲数
// 理论值：0.136mm/脉冲（车轮转一圈约1504脉冲，四倍频）
#define DISTANCE_PER_PULSE_MM  (3.1415926535f * WHEEL_DIAMETER_MM / ENCODER_PULSES_PER_REV)

// 距离校准系数（用于修正实际测量误差）
// 实际150cm显示132.3cm，校准系数 = 150 / 132.3 ≈ 1.134
#define DISTANCE_CALIBRATION   1.134f

// 距离数据结构体
typedef struct {
    float distance_A;    // 电机A行走距离（毫米）
    float distance_B;    // 电机B行走距离（毫米）
    float distance_avg;  // 平均行走距离（毫米）
    int32_t count_A;     // 电机A编码器计数值
    int32_t count_B;     // 电机B编码器计数值
} DISTANCE_DATA;

// 初始化距离计算模块
void distance_init(void);

// 更新距离数据（根据编码器计数值计算）
void distance_update(int32_t countA, int32_t countB);

// 获取距离数据
DISTANCE_DATA distance_get_data(void);

// 清零距离数据
void distance_clear(void);

// 获取平均距离（厘米）
float distance_get_avg_cm(void);

// 获取平均距离（米）
float distance_get_avg_m(void);

// 设置距离校准系数
void distance_set_calibration(float factor);

// 获取当前校准系数
float distance_get_calibration(void);

#endif /* __DISTANCE_H__ */
